.\cpu_renderer --time-limit 256
